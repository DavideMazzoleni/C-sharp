﻿namespace ControlloImmagine
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Immagine = new PictureBox();
            panel1 = new Panel();
            spir = new Button();
            Tapp = new Button();
            reseet = new Button();
            grigio = new Button();
            negativo = new Button();
            IV = new Button();
            IB = new Button();
            IR = new Button();
            TV = new Button();
            TB = new Button();
            TR = new Button();
            obliquo = new Button();
            verticale = new Button();
            orizzontale = new Button();
            Scelta = new Button();
            openFileDialog = new OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)Immagine).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // Immagine
            // 
            Immagine.Dock = DockStyle.Top;
            Immagine.Location = new Point(0, 0);
            Immagine.Name = "Immagine";
            Immagine.Size = new Size(800, 354);
            Immagine.SizeMode = PictureBoxSizeMode.Zoom;
            Immagine.TabIndex = 0;
            Immagine.TabStop = false;
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(spir);
            panel1.Controls.Add(Tapp);
            panel1.Controls.Add(reseet);
            panel1.Controls.Add(grigio);
            panel1.Controls.Add(negativo);
            panel1.Controls.Add(IV);
            panel1.Controls.Add(IB);
            panel1.Controls.Add(IR);
            panel1.Controls.Add(TV);
            panel1.Controls.Add(TB);
            panel1.Controls.Add(TR);
            panel1.Controls.Add(obliquo);
            panel1.Controls.Add(verticale);
            panel1.Controls.Add(orizzontale);
            panel1.Controls.Add(Scelta);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 350);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 100);
            panel1.TabIndex = 1;
            // 
            // spir
            // 
            spir.Location = new Point(553, 10);
            spir.Name = "spir";
            spir.Size = new Size(75, 77);
            spir.TabIndex = 14;
            spir.Text = "Spirale";
            spir.UseVisualStyleBackColor = true;
            // 
            // Tapp
            // 
            Tapp.Location = new Point(472, 9);
            Tapp.Name = "Tapp";
            Tapp.Size = new Size(75, 77);
            Tapp.TabIndex = 13;
            Tapp.Text = "Tapparella";
            Tapp.UseVisualStyleBackColor = true;
            // 
            // reseet
            // 
            reseet.Location = new Point(718, 9);
            reseet.Name = "reseet";
            reseet.Size = new Size(75, 78);
            reseet.TabIndex = 12;
            reseet.Text = "Reset Image";
            reseet.UseVisualStyleBackColor = true;
            reseet.Click += Reset;
            // 
            // grigio
            // 
            grigio.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            grigio.Location = new Point(382, 9);
            grigio.Name = "grigio";
            grigio.Size = new Size(84, 78);
            grigio.TabIndex = 11;
            grigio.Text = "Grigio";
            grigio.UseVisualStyleBackColor = true;
            grigio.Click += Grigio;
            // 
            // negativo
            // 
            negativo.Font = new Font("Segoe UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            negativo.Location = new Point(276, 9);
            negativo.Name = "negativo";
            negativo.Size = new Size(100, 78);
            negativo.TabIndex = 10;
            negativo.Text = "Negativo";
            negativo.UseVisualStyleBackColor = true;
            negativo.Click += Ngativo;
            // 
            // IV
            // 
            IV.Location = new Point(173, 64);
            IV.Name = "IV";
            IV.Size = new Size(97, 23);
            IV.TabIndex = 9;
            IV.Text = "Inverti Verde";
            IV.UseVisualStyleBackColor = true;
            IV.Click += Ngativo;
            // 
            // IB
            // 
            IB.Location = new Point(173, 38);
            IB.Name = "IB";
            IB.Size = new Size(97, 23);
            IB.TabIndex = 8;
            IB.Text = "Inverti Blu";
            IB.UseVisualStyleBackColor = true;
            IB.Click += Ngativo;
            // 
            // IR
            // 
            IR.Location = new Point(173, 9);
            IR.Name = "IR";
            IR.Size = new Size(97, 23);
            IR.TabIndex = 7;
            IR.Text = "Inverti Rosso";
            IR.UseVisualStyleBackColor = true;
            IR.Click += Ngativo;
            // 
            // TV
            // 
            TV.Location = new Point(92, 63);
            TV.Name = "TV";
            TV.Size = new Size(75, 23);
            TV.TabIndex = 6;
            TV.Text = "Togli Verde";
            TV.UseVisualStyleBackColor = true;
            TV.Click += Elimina;
            // 
            // TB
            // 
            TB.Location = new Point(91, 37);
            TB.Name = "TB";
            TB.Size = new Size(75, 23);
            TB.TabIndex = 5;
            TB.Text = "Togli Blu";
            TB.UseVisualStyleBackColor = true;
            TB.Click += Elimina;
            // 
            // TR
            // 
            TR.Location = new Point(92, 8);
            TR.Name = "TR";
            TR.Size = new Size(75, 23);
            TR.TabIndex = 4;
            TR.Text = "Togli Rosso";
            TR.UseVisualStyleBackColor = true;
            TR.Click += Elimina;
            // 
            // obliquo
            // 
            obliquo.Location = new Point(10, 63);
            obliquo.Name = "obliquo";
            obliquo.Size = new Size(75, 23);
            obliquo.TabIndex = 3;
            obliquo.Text = "Obliquo";
            obliquo.UseVisualStyleBackColor = true;
            obliquo.Click += Gira;
            // 
            // verticale
            // 
            verticale.Location = new Point(10, 36);
            verticale.Name = "verticale";
            verticale.Size = new Size(75, 23);
            verticale.TabIndex = 2;
            verticale.Text = "Verticale";
            verticale.UseVisualStyleBackColor = true;
            verticale.Click += Gira;
            // 
            // orizzontale
            // 
            orizzontale.Location = new Point(10, 8);
            orizzontale.Name = "orizzontale";
            orizzontale.Size = new Size(75, 23);
            orizzontale.TabIndex = 1;
            orizzontale.Text = "Orizzontale";
            orizzontale.UseVisualStyleBackColor = true;
            orizzontale.Click += Gira;
            // 
            // Scelta
            // 
            Scelta.Location = new Point(205, 5);
            Scelta.Name = "Scelta";
            Scelta.Size = new Size(427, 88);
            Scelta.TabIndex = 0;
            Scelta.Text = "ScegliFile";
            Scelta.UseVisualStyleBackColor = true;
            Scelta.Visible = false;
            Scelta.Click += scegli;
            // 
            // openFileDialog
            // 
            openFileDialog.FileName = "openFileDialog1";
            openFileDialog.ReadOnlyChecked = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(Immagine);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)Immagine).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private PictureBox Immagine;
        private Panel panel1;
        private Button Scelta;
        private OpenFileDialog openFileDialog;
        private Button obliquo;
        private Button verticale;
        private Button orizzontale;
        private Button TV;
        private Button TB;
        private Button TR;
        private Button IR;
        private Button IB;
        private Button IV;
        private Button negativo;
        private Button reseet;
        private Button grigio;
        private Button Tapp;
        private Button spir;
    }
}