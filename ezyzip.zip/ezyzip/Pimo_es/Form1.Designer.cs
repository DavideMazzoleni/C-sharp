﻿namespace Pimo_es
{
    partial class Bob
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            Risultato = new Label();
            label1 = new Label();
            panel2 = new Panel();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel3 = new Panel();
            button17 = new Button();
            button16 = new Button();
            button15 = new Button();
            button14 = new Button();
            button13 = new Button();
            button12 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveCaption;
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(Risultato);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(208, 49);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // Risultato
            // 
            Risultato.AutoSize = true;
            Risultato.Dock = DockStyle.Right;
            Risultato.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            Risultato.Location = new Point(167, 0);
            Risultato.Name = "Risultato";
            Risultato.RightToLeft = RightToLeft.Yes;
            Risultato.Size = new Size(37, 45);
            Risultato.TabIndex = 1;
            Risultato.Text = "0";
            Risultato.TextAlign = ContentAlignment.MiddleRight;
            Risultato.Click += label2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(227, 7);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 0;
            label1.Click += label1_Click_1;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(button11);
            panel2.Controls.Add(button10);
            panel2.Controls.Add(button9);
            panel2.Controls.Add(button8);
            panel2.Controls.Add(button7);
            panel2.Controls.Add(button6);
            panel2.Controls.Add(button5);
            panel2.Controls.Add(button4);
            panel2.Controls.Add(button3);
            panel2.Controls.Add(button2);
            panel2.Controls.Add(button1);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 49);
            panel2.Name = "panel2";
            panel2.Size = new Size(122, 124);
            panel2.TabIndex = 1;
            // 
            // button11
            // 
            button11.Location = new Point(79, 91);
            button11.Name = "button11";
            button11.Size = new Size(32, 23);
            button11.TabIndex = 10;
            button11.Text = ".";
            button11.UseVisualStyleBackColor = true;
            button11.Click += numerButton_Click;
            // 
            // button10
            // 
            button10.Location = new Point(3, 91);
            button10.Name = "button10";
            button10.Size = new Size(70, 23);
            button10.TabIndex = 9;
            button10.Text = "0";
            button10.UseVisualStyleBackColor = true;
            button10.Click += numerButton_Click;
            // 
            // button9
            // 
            button9.Location = new Point(79, 62);
            button9.Name = "button9";
            button9.Size = new Size(32, 23);
            button9.TabIndex = 8;
            button9.Text = "3";
            button9.UseVisualStyleBackColor = true;
            button9.Click += numerButton_Click;
            // 
            // button8
            // 
            button8.Location = new Point(41, 62);
            button8.Name = "button8";
            button8.Size = new Size(32, 23);
            button8.TabIndex = 7;
            button8.Text = "2";
            button8.UseVisualStyleBackColor = true;
            button8.Click += numerButton_Click;
            // 
            // button7
            // 
            button7.Location = new Point(3, 62);
            button7.Name = "button7";
            button7.Size = new Size(32, 23);
            button7.TabIndex = 6;
            button7.Text = "1";
            button7.UseVisualStyleBackColor = true;
            button7.Click += numerButton_Click;
            // 
            // button6
            // 
            button6.Location = new Point(79, 33);
            button6.Name = "button6";
            button6.Size = new Size(32, 23);
            button6.TabIndex = 5;
            button6.Text = "6";
            button6.UseVisualStyleBackColor = true;
            button6.Click += numerButton_Click;
            // 
            // button5
            // 
            button5.Location = new Point(41, 33);
            button5.Name = "button5";
            button5.Size = new Size(32, 23);
            button5.TabIndex = 4;
            button5.Text = "5";
            button5.UseVisualStyleBackColor = true;
            button5.Click += numerButton_Click;
            // 
            // button4
            // 
            button4.Location = new Point(3, 33);
            button4.Name = "button4";
            button4.Size = new Size(32, 23);
            button4.TabIndex = 3;
            button4.Text = "4";
            button4.UseVisualStyleBackColor = true;
            button4.Click += numerButton_Click;
            // 
            // button3
            // 
            button3.Location = new Point(79, 4);
            button3.Name = "button3";
            button3.Size = new Size(32, 23);
            button3.TabIndex = 2;
            button3.Text = "9";
            button3.UseVisualStyleBackColor = true;
            button3.Click += numerButton_Click;
            // 
            // button2
            // 
            button2.Location = new Point(41, 4);
            button2.Name = "button2";
            button2.Size = new Size(32, 23);
            button2.TabIndex = 1;
            button2.Text = "8";
            button2.UseVisualStyleBackColor = true;
            button2.Click += numerButton_Click;
            // 
            // button1
            // 
            button1.Location = new Point(3, 4);
            button1.Name = "button1";
            button1.Size = new Size(32, 23);
            button1.TabIndex = 0;
            button1.Text = "7";
            button1.UseVisualStyleBackColor = true;
            button1.Click += numerButton_Click;
            // 
            // panel3
            // 
            panel3.BorderStyle = BorderStyle.Fixed3D;
            panel3.Controls.Add(button17);
            panel3.Controls.Add(button16);
            panel3.Controls.Add(button15);
            panel3.Controls.Add(button14);
            panel3.Controls.Add(button13);
            panel3.Controls.Add(button12);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(122, 49);
            panel3.Name = "panel3";
            panel3.Size = new Size(86, 124);
            panel3.TabIndex = 2;
            // 
            // button17
            // 
            button17.Location = new Point(3, 91);
            button17.Name = "button17";
            button17.Size = new Size(34, 23);
            button17.TabIndex = 5;
            button17.Text = "+";
            button17.UseVisualStyleBackColor = true;
            button17.Click += operationButton_Click;
            // 
            // button16
            // 
            button16.Location = new Point(3, 62);
            button16.Name = "button16";
            button16.Size = new Size(34, 23);
            button16.TabIndex = 4;
            button16.Text = "-";
            button16.UseVisualStyleBackColor = true;
            button16.Click += operationButton_Click;
            // 
            // button15
            // 
            button15.Location = new Point(3, 4);
            button15.Name = "button15";
            button15.Size = new Size(34, 23);
            button15.TabIndex = 3;
            button15.Text = "*";
            button15.UseVisualStyleBackColor = true;
            button15.Click += operationButton_Click;
            // 
            // button14
            // 
            button14.Location = new Point(3, 33);
            button14.Name = "button14";
            button14.Size = new Size(34, 23);
            button14.TabIndex = 2;
            button14.Text = "/";
            button14.UseVisualStyleBackColor = true;
            button14.Click += operationButton_Click;
            // 
            // button13
            // 
            button13.Location = new Point(43, 4);
            button13.Name = "button13";
            button13.Size = new Size(31, 23);
            button13.TabIndex = 1;
            button13.Text = "C";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button12
            // 
            button12.Location = new Point(43, 33);
            button12.Name = "button12";
            button12.Size = new Size(32, 82);
            button12.TabIndex = 0;
            button12.Text = "=";
            button12.UseVisualStyleBackColor = true;
            button12.Click += operationButton_Click;
            // 
            // Bob
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(208, 173);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "Bob";
            Text = "Form1";
            Load += Form1_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel3.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label1;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Button button11;
        private Button button10;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button13;
        private Button button12;
        private Button button14;
        private Button button16;
        private Button button15;
        private Button button17;
        private Label Risultato;
    }
}