using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace ScorriImmagini
{
    public partial class Base : Form
    {
        private int i = 0, dimnsion;
        private string[] file = new string[0];

        public Base()
        {
            InitializeComponent();
        }

        private void START_Click(object sender, EventArgs e)
        {
            string sup = controlloVelocita.Text;
            int time = Convert.ToInt32(sup);
            //label1.Text = time.ToString();
            timer.Interval = 1000 * time;
            timer.Enabled = true;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            if (i < dimnsion - 1)
                i++;
            else
                i = 0;
            string formato = file[i].Substring((file[i].Length - 3), 3);

            if(formato == "png" || formato == "jpg" || formato == "gif")
            {
                pictureBox1.ImageLocation = file[i];
            }
            label1.Text = formato;
        }

        private void STOP_Click(object sender, EventArgs e)
        {
            timer.Enabled = false;
        }

        private void OPEN_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.ShowDialog();
            file = Directory.GetFiles(folderBrowserDialog.SelectedPath);
            dimnsion = file.Length;
            pictureBox1.ImageLocation = file[i];
        }
    }
}