﻿namespace due_forms
{
    partial class Form_principale
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Liberare le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.rosso = new System.Windows.Forms.HScrollBar();
            this.etico_rosso = new System.Windows.Forms.Label();
            this.etico_verde = new System.Windows.Forms.Label();
            this.verde = new System.Windows.Forms.HScrollBar();
            this.etico_blu = new System.Windows.Forms.Label();
            this.blu = new System.Windows.Forms.HScrollBar();
            this.SuspendLayout();
            // 
            // rosso
            // 
            this.rosso.Location = new System.Drawing.Point(93, 18);
            this.rosso.Maximum = 255;
            this.rosso.Name = "rosso";
            this.rosso.Size = new System.Drawing.Size(242, 33);
            this.rosso.TabIndex = 0;
            this.rosso.Scroll += new System.Windows.Forms.ScrollEventHandler(this.rosso_Scroll);
            // 
            // etico_rosso
            // 
            this.etico_rosso.AutoSize = true;
            this.etico_rosso.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etico_rosso.ForeColor = System.Drawing.Color.Red;
            this.etico_rosso.Location = new System.Drawing.Point(9, 18);
            this.etico_rosso.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.etico_rosso.Name = "etico_rosso";
            this.etico_rosso.Size = new System.Drawing.Size(67, 23);
            this.etico_rosso.TabIndex = 1;
            this.etico_rosso.Text = "Rosso";
            // 
            // etico_verde
            // 
            this.etico_verde.AutoSize = true;
            this.etico_verde.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etico_verde.ForeColor = System.Drawing.Color.Green;
            this.etico_verde.Location = new System.Drawing.Point(9, 60);
            this.etico_verde.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.etico_verde.Name = "etico_verde";
            this.etico_verde.Size = new System.Drawing.Size(64, 23);
            this.etico_verde.TabIndex = 3;
            this.etico_verde.Text = "Verde";
            // 
            // verde
            // 
            this.verde.Location = new System.Drawing.Point(93, 60);
            this.verde.Maximum = 255;
            this.verde.Name = "verde";
            this.verde.Size = new System.Drawing.Size(242, 33);
            this.verde.TabIndex = 2;
            this.verde.Scroll += new System.Windows.Forms.ScrollEventHandler(this.rosso_Scroll);
            // 
            // etico_blu
            // 
            this.etico_blu.AutoSize = true;
            this.etico_blu.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.etico_blu.ForeColor = System.Drawing.Color.Blue;
            this.etico_blu.Location = new System.Drawing.Point(9, 103);
            this.etico_blu.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.etico_blu.Name = "etico_blu";
            this.etico_blu.Size = new System.Drawing.Size(41, 23);
            this.etico_blu.TabIndex = 5;
            this.etico_blu.Text = "Blu";
            // 
            // blu
            // 
            this.blu.Location = new System.Drawing.Point(93, 103);
            this.blu.Maximum = 255;
            this.blu.Name = "blu";
            this.blu.Size = new System.Drawing.Size(242, 33);
            this.blu.TabIndex = 4;
            this.blu.Scroll += new System.Windows.Forms.ScrollEventHandler(this.rosso_Scroll);
            // 
            // Form_principale
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(348, 151);
            this.Controls.Add(this.etico_blu);
            this.Controls.Add(this.blu);
            this.Controls.Add(this.etico_verde);
            this.Controls.Add(this.verde);
            this.Controls.Add(this.etico_rosso);
            this.Controls.Add(this.rosso);
            this.Location = new System.Drawing.Point(200, 300);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Form_principale";
            this.Text = "Comandi";
            this.Shown += new System.EventHandler(this.form_principale_Shown);
            this.LocationChanged += new System.EventHandler(this.Form_principale_LocationChanged);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.HScrollBar rosso;
        private System.Windows.Forms.Label etico_rosso;
        private System.Windows.Forms.Label etico_verde;
        private System.Windows.Forms.HScrollBar verde;
        private System.Windows.Forms.Label etico_blu;
        private System.Windows.Forms.HScrollBar blu;
    }
}

