﻿namespace TestVerifica
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            villette1 = new Villette();
            SuspendLayout();
            // 
            // villette1
            // 
            villette1.Location = new Point(12, 12);
            villette1.Name = "villette1";
            villette1.Occu1 = true;
            villette1.Occu2 = false;
            villette1.Occu3 = true;
            villette1.Occu4 = false;
            villette1.Occu5 = true;
            villette1.Pscina1 = Pisc.No;
            villette1.Pscina2 = Pisc.Piccola;
            villette1.Pscina3 = Pisc.No;
            villette1.Pscina4 = Pisc.No;
            villette1.Pscina5 = Pisc.Piccola;
            villette1.Situazione1 = Situa.Venduta;
            villette1.Situazione2 = Situa.Venduta;
            villette1.Situazione3 = Situa.Venduta;
            villette1.Situazione4 = Situa.Ristrutturazione;
            villette1.Situazione5 = Situa.Ristrutturazione;
            villette1.Size = new Size(442, 375);
            villette1.TabIndex = 0;
            villette1.Text = "villette1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(villette1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Villette villette1;
    }
}
