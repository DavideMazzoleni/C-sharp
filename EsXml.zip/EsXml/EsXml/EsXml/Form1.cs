using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Pipes;
using System.Xml;

namespace EsXml
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Avvia_algo(object sender, EventArgs e)
        {
            String fileLegami = ".\\Lavoro\\LEGAMI.txt";
            String fileLTipi_rette = ".\\Lavoro\\TIPI_RETTE.txt";
            String fileUtenti = ".\\Lavoro\\UTENTI.txt";
            String fileCreate = @".\rimasto.xml";
            bool elaborare = true;

            listBox1.Items.Clear();

            if(File.Exists(fileCreate) )
            {
                if (MessageBox.Show("Il file [" + fileCreate + "] � gi� stato creato.\n\nDevo eseguire l'elaborazione?", "Attenzione", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2) == DialogResult.No)
                {
                    listBox1.Items.Add("Elaborazione interrotta: il file [" + fileCreate + "] esiste gi�.");
                    elaborare = false;
                }
            }
            if(elaborare) {
                listBox1.Items.Add("OK");
                if(File.Exists (fileLTipi_rette) && File.Exists(fileUtenti) && File.Exists(fileLegami) ) 
                {
                    XmlDocument Rimasto = new XmlDocument();
                    XmlNode nodo_dichiarativo = Rimasto.CreateXmlDeclaration("1.0", "UTF-8", null);
                    Rimasto.AppendChild(nodo_dichiarativo);
                    XmlNode nodo_root = Rimasto.CreateElement("Rette_utenti");
                    Rimasto.AppendChild (nodo_root);

                    listBox1.Items.Add(" Elaborazione del file [" + fileUtenti + "].");
                    var file_primario = new System.IO.StreamReader(fileUtenti, System.Text.Encoding.UTF8, true, 128);
                    String riga;

                    Dictionary<double, List<string>> serviziPerNumero = new Dictionary<double, List<string>>();


                    string[] righeFile = File.ReadAllLines(fileLegami);
                    foreach (string rigo in righeFile)
                    {
                        string[] colonne = rigo.Split(';');
                        double numero = Convert.ToDouble(colonne[0]);
                        string servizio = colonne[1];


                        if (!serviziPerNumero.ContainsKey(numero))
                        {
                            serviziPerNumero[numero] = new List<string>();
                        }
                        serviziPerNumero[numero].Add(servizio);
                    }


                    List<string> matrice1 = new List<string>();
                    List<string> matrice2 = new List<string>();

                    string[] righoFile = File.ReadAllLines(fileLTipi_rette);
                    foreach (string rigo in righoFile)
                    {
                        matrice1.Add((rigo.Split(';'))[0]);
                        matrice2.Add((rigo.Split(';'))[1]);
                    }

                    int i = 1;
                    int j = 0;
                    while ((riga = file_primario.ReadLine()) != null)
                    {
                        String[] campi = riga.Split(';');
                        XmlNode nodo_Utente = Rimasto.CreateElement("utente");
                        nodo_root.AppendChild(nodo_Utente);
                        XmlNode nodo = Rimasto.CreateElement("codice");
                        nodo.InnerText = (campi[0].Split(','))[0];
                        nodo_Utente.AppendChild(nodo);
                        XmlNode nodo_cognome = Rimasto.CreateElement("cognome");
                        nodo_cognome.InnerText = campi[1];
                        nodo_Utente.AppendChild(nodo_cognome);
                        XmlNode nodo_nome = Rimasto.CreateElement("nome");
                        nodo_nome.InnerText = campi[2];
                        nodo_Utente.AppendChild(nodo_nome);
                        String[] nascita = campi[3].Split(" ");
                        XmlNode nodo_data = Rimasto.CreateElement("data_nascita");
                        nodo_data.InnerText = nascita[0];
                        nodo_Utente.AppendChild(nodo_data);
                        XmlNode nodo_orario = Rimasto.CreateElement("orario_nascita");
                        nodo_orario.InnerText = nascita[1];
                        nodo_Utente.AppendChild(nodo_orario);
                        XmlNode nodo_sesso = Rimasto.CreateElement("sesso");
                        nodo_sesso.InnerText = campi[4];
                        nodo_Utente.AppendChild(nodo_sesso);
                        XmlNode nodo_scuola = Rimasto.CreateElement("scuola");
                        nodo_scuola.InnerText = campi[5];
                        nodo_Utente.AppendChild(nodo_scuola);
                        XmlNode nodo_classe = Rimasto.CreateElement("classe");
                        nodo_classe.InnerText = campi[6];
                        nodo_Utente.AppendChild(nodo_classe);
                        XmlNode nodo_sezione = Rimasto.CreateElement("sezione");
                        nodo_sezione.InnerText = campi[7];
                        nodo_Utente.AppendChild(nodo_sezione);
                        XmlNode nodo_cognome_geni = Rimasto.CreateElement("cognome_genitore");
                        nodo_cognome_geni.InnerText = campi[8];
                        nodo_Utente.AppendChild(nodo_cognome_geni);
                        XmlNode nodo_nome_geni = Rimasto.CreateElement("nome_genitore");
                        nodo_nome_geni.InnerText = campi[9];
                        nodo_Utente.AppendChild(nodo_nome_geni);
                        XmlNode nodo_servizi = Rimasto.CreateElement("servizi");
                        nodo_Utente.AppendChild (nodo_servizi);
                        j = 0;
                        if (serviziPerNumero.ContainsKey(i))
                        {
                            foreach (string servizio in serviziPerNumero[i])
                            {
                                XmlNode nodo_servizio = Rimasto.CreateElement("servizio");
                                nodo_servizio.InnerText = matrice2[matrice1.IndexOf(servizio)];
                                nodo_servizi.AppendChild(nodo_servizio);
                            }
                        }
                        else
                        {
                            // Se la chiave non � presente, aggiungi un nodo di servizio vuoto
                            XmlNode nodo_servizio = Rimasto.CreateElement("servizio");
                            nodo_servizi.AppendChild(nodo_servizio);
                        }
                        i++;
                    }
                    file_primario.Close();
                    Rimasto.Save(fileCreate);
                }
            }
            else
            {
                MessageBox.Show("Non trovo i file [" + fileLegami + "] e/o [" + fileLTipi_rette + "] e/o [" + fileUtenti + "] necessari per l'elaborazione!", "Attenzione", MessageBoxButtons.OK);
                listBox1.Items.Add("Non trovo i file [" + fileLegami + "] e/o [" + fileLTipi_rette + "] e/o [" + fileUtenti + "] necessari per l'elaborazione!");
            }
            listBox1.Items.Add("FINE ELABORAZIONE");


        }
    }
}
