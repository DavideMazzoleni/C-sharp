﻿namespace ScorriImmagini
{
    partial class Base
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Base));
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            controlloVelocita = new DomainUpDown();
            pictureBox1 = new PictureBox();
            timer = new System.Windows.Forms.Timer(components);
            folderBrowserDialog = new FolderBrowserDialog();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox2);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(controlloVelocita);
            panel1.Dock = DockStyle.Bottom;
            panel1.Location = new Point(0, 356);
            panel1.Name = "panel1";
            panel1.Size = new Size(800, 94);
            panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(10, 20);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(63, 54);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 7;
            pictureBox2.TabStop = false;
            pictureBox2.Click += OPEN_Click;
            // 
            // button5
            // 
            button5.Location = new Point(274, 20);
            button5.Name = "button5";
            button5.Size = new Size(61, 54);
            button5.TabIndex = 5;
            button5.Text = "EXIT";
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(207, 20);
            button4.Name = "button4";
            button4.Size = new Size(61, 54);
            button4.TabIndex = 4;
            button4.Text = "STOP";
            button4.UseVisualStyleBackColor = true;
            button4.Click += STOP_Click;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button3.Location = new Point(697, 16);
            button3.Name = "button3";
            button3.Size = new Size(89, 62);
            button3.TabIndex = 3;
            button3.Text = "OFF";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(140, 20);
            button2.Name = "button2";
            button2.Size = new Size(61, 54);
            button2.TabIndex = 2;
            button2.Text = "START";
            button2.UseVisualStyleBackColor = true;
            button2.Click += START_Click;
            // 
            // controlloVelocita
            // 
            controlloVelocita.Font = new Font("Segoe UI", 26.25F, FontStyle.Regular, GraphicsUnit.Point);
            controlloVelocita.Items.Add("4");
            controlloVelocita.Items.Add("3");
            controlloVelocita.Items.Add("2");
            controlloVelocita.Items.Add("1");
            controlloVelocita.Location = new Point(79, 20);
            controlloVelocita.Name = "controlloVelocita";
            controlloVelocita.ReadOnly = true;
            controlloVelocita.Size = new Size(55, 54);
            controlloVelocita.TabIndex = 0;
            controlloVelocita.Text = "1";
            controlloVelocita.TextAlign = HorizontalAlignment.Right;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 356);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // timer
            // 
            timer.Tick += timer_Tick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(524, 46);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 8;
            label1.Text = "label1";
            // 
            // Base
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(pictureBox1);
            Controls.Add(panel1);
            Name = "Base";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "abrok";
            WindowState = FormWindowState.Maximized;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private DomainUpDown controlloVelocita;
        private PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button5;
        public FolderBrowserDialog folderBrowserDialog;
        private PictureBox pictureBox2;
        private Label label1;
    }
}