﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace provaVerifica
{
    public partial class FormImmagine : Form
    {
        public FormImmagine()
        {
            InitializeComponent();
        }

        public void OpenImage(string filepath)
        {
            containerImmagine.Image = Image.FromFile(filepath);
        }
    }
}
