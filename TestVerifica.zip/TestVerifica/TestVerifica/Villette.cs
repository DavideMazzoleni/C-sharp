﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestVerifica
{
    public enum Situa
    {
        Venduta, Affittata, Ristrutturazione
    }

    public enum Pisc
    {
        No, Grande, Piccola
    }
    internal class Villette : Control
    {
        Color coloreOcc = Color.Red;
        Color coloreNonOcc = Color.Green;
        int spesso = 1;
        bool[] Occupate = new bool[5];
       
        Situa[] Situazione = new Situa[5];
        Pisc[] Piscine = new Pisc[5];
        protected override void OnPaint(PaintEventArgs pe)
        {
            int larghezza = base.Width;
            larghezza -= 12;
            larghezza /= 5;
            int altezza = base.Height;
            altezza -= 12;
            altezza /= 5;
            int PosStartX = 2;
            int PosStartY = 2;
            Graphics g = pe.Graphics;
            for(int i=0; i<5; i++)
            {
                Pen penna = new Pen(coloreNonOcc, spesso);
                if (Occupate[i])
                {
                    penna.Color = coloreOcc;
                    if (Situazione[i] == Situa.Affittata)
                    {
                        Point p1 = new Point(PosStartX + (larghezza/2), PosStartY + altezza);
                        Point p2 = new Point(PosStartX + larghezza, PosStartY + (altezza/2));
                        g.DrawLine(penna,p1,p2);
                    }
                    if (Situazione[i] == Situa.Venduta)
                    {
                        Point p1 = new Point(PosStartX + (larghezza / 2), PosStartY);
                        Point p2 = new Point(PosStartX, PosStartY + (altezza / 2));
                        g.DrawLine(penna, p1, p2);
                    }
                    if (Situazione[i] == Situa.Ristrutturazione)
                    {
                        Point p1 = new Point(PosStartX, PosStartY );
                        Point p2 = new Point(PosStartX + larghezza, PosStartY + altezza);
                        g.DrawLine(penna, p1, p2);
                        p1.X = PosStartX;
                        p1.Y = PosStartY + altezza;
                        p2.X = PosStartX + larghezza;
                        p2.Y = PosStartY;
                        g.DrawLine(penna, p1, p2);
                    }
                    if (Piscine[i] == Pisc.Piccola)
                    {
                        Pen penna2 = new Pen(Color.Blue,2);
                        g.DrawRectangle(penna2, PosStartX + larghezza/ 3, PosStartY + altezza/ 3, larghezza / 3, altezza / 3);
                    }
                    if (Piscine[i] == Pisc.Grande)
                    {
                        Pen penna2 = new Pen(Color.Blue, 2);
                        g.DrawRectangle(penna2, PosStartX + larghezza / 4, PosStartY + altezza / 4, larghezza / 2, altezza / 2);
                    }
                }
                else
                    penna.Color = coloreNonOcc;

                g.DrawRectangle(penna, PosStartX, PosStartY, larghezza, altezza);
                PosStartX += larghezza + 2 ;
                PosStartY += altezza + 2;
            }
            //MessageBox.Show("disegno");
        }

        public Boolean Occu1
        {
            get
            {
                return Occupate[0];
            }
            set
            {
                Occupate[0] = value;
                Invalidate();
            }
        }
        public Boolean Occu2
        {
            get
            {
                return Occupate[1];
            }
            set
            {
                Occupate[1] = value;
                Invalidate();
            }
        }
        public Boolean Occu3
        {
            get
            {
                return Occupate[2];
            }
            set
            {
                Occupate[2] = value;
                Invalidate();
            }
        }
        public Boolean Occu4
        {
            get
            {
                return Occupate[3];
            }
            set
            {
                Occupate[3] = value;
                Invalidate();
            }
        }
        public Boolean Occu5
        {
            get
            {
                return Occupate[4];
            }
            set
            {
                Occupate[4] = value;
                Invalidate();
            }
        }

        public Situa Situazione1
        {
            get
            {
                return Situazione[0];
            }
            set
            {
                Situazione[0] = value;
                Invalidate();
            }
        }
        public Situa Situazione2
        {
            get
            {
                return Situazione[1];
            }
            set
            {
                Situazione[1] = value;
                Invalidate();
            }
        }
        public Situa Situazione3
        {
            get
            {
                return Situazione[2];
            }
            set
            {
                Situazione[2] = value;
                Invalidate();
            }
        }
        public Situa Situazione4
        {
            get
            {
                return Situazione[3];
            }
            set
            {
                Situazione[3] = value;
                Invalidate();
            }
        }
        public Situa Situazione5
        {
            get
            {
                return Situazione[4];
            }
            set
            {
                Situazione[4] = value;
                Invalidate();
            }
        }

        public Pisc Pscina1
        {
            get
            {
                return Piscine[0];
            }
            set
            {
                Piscine[0] = value;
                Invalidate();
            }
        }
        public Pisc Pscina2
        {
            get
            {
                return Piscine[1];
            }
            set
            {
                Piscine[1] = value;
                Invalidate();
            }
        }
        public Pisc Pscina3
        {
            get
            {
                return Piscine[2];
            }
            set
            {
                Piscine[2] = value;
                Invalidate();
            }
        }
        public Pisc Pscina4
        {
            get
            {
                return Piscine[3];
            }
            set
            {
                Piscine[3] = value;
                Invalidate();
            }
        }
        public Pisc Pscina5
        {
            get
            {
                return Piscine[4];
            }
            set
            {
                Piscine[4] = value;
                Invalidate();
            }
        }
    }
}
