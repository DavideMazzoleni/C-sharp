﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace due_forms
{
    public partial class Form_principale : Form
    {
        Form_Colori altra_form;
        public Form_principale()
        {
            InitializeComponent();
            altra_form = new Form_Colori();
        }
        private void form_principale_Shown(object sender, EventArgs e)
        {
            altra_form.Show();
            sposta_form_secondaria();
            cambia_colore_altra_form();
        }
        private void Form_principale_LocationChanged(object sender, EventArgs e)
        {
            sposta_form_secondaria();
        }

        private void sposta_form_secondaria()
        {
            altra_form.Location = new Point(Location.X + Size.Width + 10, Location.Y);
            //altra_form.Top = Top;
            //altra_form.Left = Left + Width + 10;


        }

        private void rosso_Scroll(object sender, ScrollEventArgs e)
        {
            cambia_colore_altra_form();
        }
        private void cambia_colore_altra_form()
        {
            altra_form.BackColor = Color.FromArgb(rosso.Value, verde.Value, blu.Value);
        }



    }
}





