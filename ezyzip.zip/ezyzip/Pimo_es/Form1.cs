using System.Linq.Expressions;

namespace Pimo_es
{
    public partial class Bob : Form
    {
        private double val1 = 0, val2;
        private String operazione = "", num1 = "" , num2 = "";
        private bool press = false, equal_press = false;
        private int i = 0;
        public Bob()
        {
            InitializeComponent();
            Risultato.Text = "0";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        //bottone C
        private void button13_Click(object sender, EventArgs e)
        {
            operazione = "";
            num1 = "";
            press = false;
            Risultato.Text = "0";
        }

        private void operationButton_Click(object sender, EventArgs e)
        {
            if (i == 0)
                val1 = Convert.ToDouble(num1);

            if(((Button)sender).Text != "=")
                operazione += ((Button)sender).Text;
            press = true;
            if (num2 != "")
            {
                val2 = Convert.ToDouble(num2);
                switch (operazione[i])
                {
                    case '+':
                        val1 += val2;
                        break;
                    case '-':
                        val1 -= val2;
                        break;
                    case '*':
                        val1 *= val2;
                        break;
                    case '/':
                        val1 /= val2;
                        break;
                }

                if(((Button)sender).Text == "=")
                {
                    equal_press = true;
                    num1 = val1.ToString();
                    operazione = "";
                    i = 0;
                    num1 = "";
                }else {
                    i++;
                    num2 = "";
                }
            }
            MessageBox.Show(operazione + " " + val1 + " " + num1);
            Risultato.Text = val1.ToString();
        }

        private void numerButton_Click(object sender, EventArgs e)
        {
            if (equal_press && num1 == "")
            {
                num1 = "";
                operazione = "";
                num2 = "";
                val1 = val2 = 0;
            }

            equal_press = false;

            if (num1 == "" || !press)
            {
                num1 += ((Button)sender).Text;
                Risultato.Text = num1;
            }
            else
            {
                num2 += ((Button)sender).Text;
                Risultato.Text = num2;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}