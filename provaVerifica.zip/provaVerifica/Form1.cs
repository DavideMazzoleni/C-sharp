namespace provaVerifica
{
    public partial class Form1 : Form
    {
        private string[] pathImmagini;
        private int immagineAttuale;
        private FormImmagine form2;

        public Form1()
        {
            InitializeComponent();
            pathImmagini = Directory.GetFiles("../../../risorse", "*");
            immagineAttuale = 0;
            form2 = new FormImmagine();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void ImmagineDopo(object sender, EventArgs e)
        {
            immagineAttuale++;
            immagineAttuale %= pathImmagini.Length;

            contenitoreImmagine.Image.Dispose();

            contenitoreImmagine.Image = Image.FromFile(pathImmagini[immagineAttuale]);
            sottotitolo.Text = "Immagine " + (immagineAttuale + 1);
        }

        private void ImmaginePrima(object sender, EventArgs e)
        {
            immagineAttuale--;
            if (immagineAttuale < 0)
                immagineAttuale = pathImmagini.Length - 1;

            contenitoreImmagine.Image.Dispose();

            contenitoreImmagine.Image = Image.FromFile(pathImmagini[immagineAttuale]);
            sottotitolo.Text = "Immagine " + (immagineAttuale + 1);
        }

        private void CambiaTimer(object sender, EventArgs e)
        {
            timerScorrimento.Interval = trackbarScorrimento.Value * 1000;
        }

        private void AvviaStopTimer(object sender, EventArgs e)
        {
            if (timerScorrimento.Enabled)
            {
                timerScorrimento.Stop();
                bottoneTimer.Text = "Avvia timer";
            }
            else
            {
                timerScorrimento.Start();
                bottoneTimer.Text = "Ferma timer";
            }
        }

        private void ApriImmagine(object sender, EventArgs e)
        {
            form2 = new FormImmagine();
            form2.OpenImage(pathImmagini[immagineAttuale]);
            
            form2.Show();
        }
    }
}
