﻿namespace slideshow
{
    partial class Form1
    {
        /// <summary>
        /// Variabile di progettazione necessaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Pulire le risorse in uso.
        /// </summary>
        /// <param name="disposing">ha valore true se le risorse gestite devono essere eliminate, false in caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Codice generato da Progettazione Windows Form

        /// <summary>
        /// Metodo necessario per il supporto della finestra di progettazione. Non modificare
        /// il contenuto del metodo con l'editor di codice.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelTrackbar = new System.Windows.Forms.Label();
            this.intervalTrackbar = new System.Windows.Forms.TrackBar();
            this.stopButton = new System.Windows.Forms.PictureBox();
            this.fileExplorerButton = new System.Windows.Forms.PictureBox();
            this.playPauseButton = new System.Windows.Forms.PictureBox();
            this.contenitoreImmagini = new System.Windows.Forms.PictureBox();
            this.browserCartella = new System.Windows.Forms.FolderBrowserDialog();
            this.slideshowTimer = new System.Windows.Forms.Timer(this.components);
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.intervalTrackbar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileExplorerButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.playPauseButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.contenitoreImmagini)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(484, 79);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(234)))), ((int)(((byte)(234)))));
            this.panel2.Controls.Add(this.labelTrackbar);
            this.panel2.Controls.Add(this.intervalTrackbar);
            this.panel2.Controls.Add(this.stopButton);
            this.panel2.Controls.Add(this.fileExplorerButton);
            this.panel2.Controls.Add(this.playPauseButton);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 380);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(484, 70);
            this.panel2.TabIndex = 1;
            // 
            // labelTrackbar
            // 
            this.labelTrackbar.AutoSize = true;
            this.labelTrackbar.Location = new System.Drawing.Point(143, 3);
            this.labelTrackbar.Name = "labelTrackbar";
            this.labelTrackbar.Size = new System.Drawing.Size(174, 13);
            this.labelTrackbar.TabIndex = 5;
            this.labelTrackbar.Text = "Intervallo di scorrimento: 1 secondo";
            this.labelTrackbar.Visible = false;
            // 
            // intervalTrackbar
            // 
            this.intervalTrackbar.Location = new System.Drawing.Point(143, 15);
            this.intervalTrackbar.Maximum = 15;
            this.intervalTrackbar.Minimum = 1;
            this.intervalTrackbar.Name = "intervalTrackbar";
            this.intervalTrackbar.Size = new System.Drawing.Size(273, 45);
            this.intervalTrackbar.TabIndex = 4;
            this.intervalTrackbar.TabStop = false;
            this.intervalTrackbar.Value = 1;
            this.intervalTrackbar.Visible = false;
            this.intervalTrackbar.ValueChanged += new System.EventHandler(this.intervalTrackbar_ValueChanged);
            // 
            // stopButton
            // 
            this.stopButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.stopButton.Image = ((System.Drawing.Image)(resources.GetObject("stopButton.Image")));
            this.stopButton.Location = new System.Drawing.Point(80, 10);
            this.stopButton.Margin = new System.Windows.Forms.Padding(10);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(50, 50);
            this.stopButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.stopButton.TabIndex = 3;
            this.stopButton.TabStop = false;
            this.stopButton.Visible = false;
            this.stopButton.Click += new System.EventHandler(this.StopButton_Click);
            // 
            // fileExplorerButton
            // 
            this.fileExplorerButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.fileExplorerButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.fileExplorerButton.Image = ((System.Drawing.Image)(resources.GetObject("fileExplorerButton.Image")));
            this.fileExplorerButton.Location = new System.Drawing.Point(424, 10);
            this.fileExplorerButton.Margin = new System.Windows.Forms.Padding(10);
            this.fileExplorerButton.Name = "fileExplorerButton";
            this.fileExplorerButton.Size = new System.Drawing.Size(50, 50);
            this.fileExplorerButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fileExplorerButton.TabIndex = 1;
            this.fileExplorerButton.TabStop = false;
            this.fileExplorerButton.DoubleClick += new System.EventHandler(this.FileExplorerButton_Click);
            // 
            // playPauseButton
            // 
            this.playPauseButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.playPauseButton.Image = ((System.Drawing.Image)(resources.GetObject("playPauseButton.Image")));
            this.playPauseButton.Location = new System.Drawing.Point(10, 10);
            this.playPauseButton.Margin = new System.Windows.Forms.Padding(10);
            this.playPauseButton.Name = "playPauseButton";
            this.playPauseButton.Size = new System.Drawing.Size(50, 50);
            this.playPauseButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.playPauseButton.TabIndex = 0;
            this.playPauseButton.TabStop = false;
            this.playPauseButton.Visible = false;
            this.playPauseButton.Click += new System.EventHandler(this.PlayPauseButton_Click);
            // 
            // contenitoreImmagini
            // 
            this.contenitoreImmagini.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contenitoreImmagini.Location = new System.Drawing.Point(0, 79);
            this.contenitoreImmagini.Name = "contenitoreImmagini";
            this.contenitoreImmagini.Size = new System.Drawing.Size(484, 301);
            this.contenitoreImmagini.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.contenitoreImmagini.TabIndex = 2;
            this.contenitoreImmagini.TabStop = false;
            // 
            // browserCartella
            // 
            this.browserCartella.HelpRequest += new System.EventHandler(this.browserCartella_HelpRequest);
            // 
            // slideshowTimer
            // 
            this.slideshowTimer.Interval = 1000;
            this.slideshowTimer.Tick += new System.EventHandler(this.UpdateImage);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(484, 450);
            this.Controls.Add(this.contenitoreImmagini);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(500, 450);
            this.Name = "Form1";
            this.Text = "Slideshow Player";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.intervalTrackbar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stopButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileExplorerButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.playPauseButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.contenitoreImmagini)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox stopButton;
        private System.Windows.Forms.PictureBox fileExplorerButton;
        private System.Windows.Forms.PictureBox playPauseButton;
        private System.Windows.Forms.TrackBar intervalTrackbar;
        private System.Windows.Forms.PictureBox contenitoreImmagini;
        private System.Windows.Forms.Label labelTrackbar;
        private System.Windows.Forms.FolderBrowserDialog browserCartella;
        private System.Windows.Forms.Timer slideshowTimer;
    }
}

