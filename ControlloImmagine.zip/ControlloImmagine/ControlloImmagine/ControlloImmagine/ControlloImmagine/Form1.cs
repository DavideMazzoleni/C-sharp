using System.Windows.Forms;

namespace ControlloImmagine
{
    public partial class Form1 : Form
    {

        String file;
        public Form1()
        {
            InitializeComponent();
        }

        private void scegli(object sender, EventArgs e)
        {
            //folderBrowserDialog.ShowDialog();
            openFileDialog.ShowDialog();
            file = openFileDialog.FileName;
            Immagine.ImageLocation = file;
            Scelta.Visible = false;
            orizzontale.Visible = true;
            verticale.Visible = true;
            obliquo.Visible = true;
            TR.Visible = true;
            TB.Visible = true;
            TV.Visible = true;
            IR.Visible = true;
            IB.Visible = true;
            IV.Visible = true;
            negativo.Visible = true;
            grigio.Visible = true;
            Tapp.Visible = true;
            reseet.Visible = true;
            spir.Visible = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Scelta.Visible = true;
            orizzontale.Visible = false;
            verticale.Visible = false;
            obliquo.Visible = false;
            TR.Visible = false;
            TB.Visible = false;
            TV.Visible = false;
            IR.Visible = false;
            IB.Visible = false;
            IV.Visible = false;
            negativo.Visible = false;
            grigio.Visible = false;
            Tapp.Visible = false;
            reseet.Visible = false;
            spir.Visible = false;
        }

        private void Ngativo(object sender, EventArgs e)
        {
            Bitmap mappa;
            Color colore;
            byte coloreR, coloreG, coloreB;
            mappa = (Bitmap)Immagine.Image;
            Button button = (Button)sender;

            for (int i = 0; i < mappa.Width; i++)
            {
                for (int j = 0; j < mappa.Height; j++)
                {
                    colore = mappa.GetPixel(i, j);
                    coloreB = colore.B;
                    coloreR = colore.R;
                    coloreG = colore.G;

                    if (button.Text.Equals("Inverti Blu") || button.Text.Equals("Negativo"))
                        coloreB = (byte)(255 - coloreB);
                    if (button.Text.Equals("Inverti Rosso") || button.Text.Equals("Negativo"))
                        coloreR = (byte)(255 - coloreR);
                    if (button.Text.Equals("Inverti Verde") || button.Text.Equals("Negativo"))
                        coloreG = (byte)(255 - coloreG);

                    colore = Color.FromArgb(coloreR, coloreG, coloreB);
                    mappa.SetPixel(i, j, colore);

                }
            }

            Immagine.Image = mappa;
            Immagine.Invalidate();
        }

        private void Gira(object sender, EventArgs e)
        {
            Bitmap mappa;
            mappa = (Bitmap)Immagine.Image;
            Button button = (Button)sender;

            if (button.Text.Equals("Orizzontale"))
                mappa.RotateFlip(RotateFlipType.Rotate180FlipY);
            else if (button.Text.Equals("Verticale"))
                mappa.RotateFlip(RotateFlipType.Rotate180FlipX);
            else
            {
                mappa.RotateFlip(RotateFlipType.Rotate180FlipY);
                mappa.RotateFlip(RotateFlipType.Rotate180FlipX);
            }


            Immagine.Image = mappa;
            Immagine.Invalidate();
        }

        private void Elimina(object sender, EventArgs e)
        {
            Bitmap mappa;
            Color colore;
            byte coloreR, coloreG, coloreB;
            mappa = (Bitmap)Immagine.Image;
            Button button = (Button)sender;

            for (int i = 0; i < mappa.Width; i++)
            {
                for (int j = 0; j < mappa.Height; j++)
                {
                    colore = mappa.GetPixel(i, j);
                    coloreB = colore.B;
                    coloreR = colore.R;
                    coloreG = colore.G;

                    if (button.Text.Equals("Togli Blu"))
                        coloreB = 0;
                    if (button.Text.Equals("Togli Rosso"))
                        coloreR = 0;
                    if (button.Text.Equals("Togli Verde"))
                        coloreG = 0;

                    colore = Color.FromArgb(coloreR, coloreG, coloreB);
                    mappa.SetPixel(i, j, colore);

                }
            }

            Immagine.Image = mappa;
            Immagine.Invalidate();
        }

        private void Grigio(object sender, EventArgs e)
        {
            Bitmap mappa;
            Color colore;
            byte coloreR, coloreG, coloreB, media;
            mappa = (Bitmap)Immagine.Image;

            for (int i = 0; i < mappa.Width; i++)
            {
                for (int j = 0; j < mappa.Height; j++)
                {
                    colore = mappa.GetPixel(i, j);
                    coloreB = colore.B;
                    coloreR = colore.R;
                    coloreG = colore.G;

                    media = (byte)((coloreB + coloreG + coloreR) / 3);

                    coloreB = media;
                    coloreR = media;
                    coloreG = media;

                    colore = Color.FromArgb(media, media, media);
                    mappa.SetPixel(i, j, colore);

                }
            }

            Immagine.Image = mappa;
            Immagine.Invalidate();
        }

        private void Reset(object sender, EventArgs e)
        {
            Immagine.ImageLocation = file;
        }
    }
}