﻿namespace provaVerifica
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            bottonePrevious = new Button();
            bottoneNext = new Button();
            contenitoreImmagine = new PictureBox();
            sottotitolo = new Label();
            timerScorrimento = new System.Windows.Forms.Timer(components);
            bottoneTimer = new Button();
            trackbarScorrimento = new TrackBar();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)contenitoreImmagine).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trackbarScorrimento).BeginInit();
            SuspendLayout();
            // 
            // bottonePrevious
            // 
            bottonePrevious.Location = new Point(24, 176);
            bottonePrevious.Name = "bottonePrevious";
            bottonePrevious.Size = new Size(188, 29);
            bottonePrevious.TabIndex = 0;
            bottonePrevious.Text = "Immagine precedente";
            bottonePrevious.UseVisualStyleBackColor = true;
            bottonePrevious.Click += ImmaginePrima;
            // 
            // bottoneNext
            // 
            bottoneNext.Location = new Point(615, 176);
            bottoneNext.Name = "bottoneNext";
            bottoneNext.Size = new Size(173, 29);
            bottoneNext.TabIndex = 1;
            bottoneNext.Text = "Immagine seguente";
            bottoneNext.UseVisualStyleBackColor = true;
            bottoneNext.Click += ImmagineDopo;
            // 
            // contenitoreImmagine
            // 
            contenitoreImmagine.Image = (Image)resources.GetObject("contenitoreImmagine.Image");
            contenitoreImmagine.Location = new Point(242, 89);
            contenitoreImmagine.Name = "contenitoreImmagine";
            contenitoreImmagine.Size = new Size(316, 202);
            contenitoreImmagine.SizeMode = PictureBoxSizeMode.Zoom;
            contenitoreImmagine.TabIndex = 2;
            contenitoreImmagine.TabStop = false;
            // 
            // sottotitolo
            // 
            sottotitolo.Location = new Point(242, 304);
            sottotitolo.Name = "sottotitolo";
            sottotitolo.Size = new Size(316, 25);
            sottotitolo.TabIndex = 3;
            sottotitolo.Text = "Immagine 1";
            sottotitolo.TextAlign = ContentAlignment.MiddleCenter;
            sottotitolo.Click += label1_Click;
            // 
            // timerScorrimento
            // 
            timerScorrimento.Interval = 1000;
            timerScorrimento.Tick += ImmagineDopo;
            // 
            // bottoneTimer
            // 
            bottoneTimer.Location = new Point(24, 374);
            bottoneTimer.Name = "bottoneTimer";
            bottoneTimer.Size = new Size(94, 29);
            bottoneTimer.TabIndex = 4;
            bottoneTimer.Text = "Avvia timer";
            bottoneTimer.UseVisualStyleBackColor = true;
            bottoneTimer.Click += AvviaStopTimer;
            // 
            // trackbarScorrimento
            // 
            trackbarScorrimento.Location = new Point(151, 374);
            trackbarScorrimento.Minimum = 1;
            trackbarScorrimento.Name = "trackbarScorrimento";
            trackbarScorrimento.Size = new Size(343, 56);
            trackbarScorrimento.TabIndex = 5;
            trackbarScorrimento.Value = 1;
            trackbarScorrimento.Scroll += CambiaTimer;
            // 
            // button4
            // 
            button4.Location = new Point(615, 222);
            button4.Name = "button4";
            button4.Size = new Size(173, 55);
            button4.TabIndex = 6;
            button4.Text = "Apri immagine in altra scheda";
            button4.UseVisualStyleBackColor = true;
            button4.Click += ApriImmagine;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button4);
            Controls.Add(trackbarScorrimento);
            Controls.Add(bottoneTimer);
            Controls.Add(sottotitolo);
            Controls.Add(contenitoreImmagine);
            Controls.Add(bottoneNext);
            Controls.Add(bottonePrevious);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)contenitoreImmagine).EndInit();
            ((System.ComponentModel.ISupportInitialize)trackbarScorrimento).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button bottonePrevious;
        private Button bottoneNext;
        private PictureBox contenitoreImmagine;
        private Label sottotitolo;
        private System.Windows.Forms.Timer timerScorrimento;
        private Button bottoneTimer;
        private TrackBar trackbarScorrimento;
        private Button button4;
    }
}
