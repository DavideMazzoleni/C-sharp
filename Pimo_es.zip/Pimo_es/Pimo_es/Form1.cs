using System.Linq.Expressions;

namespace Pimo_es
{
    public partial class Bob : Form
    {

        private String operazione = "";
        public Bob()
        {
            InitializeComponent();
            Risultato.Text = "0";
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button13_Click(object sender, EventArgs e)
        {
            operazione = "";
            Risultato.Text = "0";
        }

        private void button14_Click(object sender, EventArgs e)
        {

        }

        private void button16_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            operazione += button10.Text;
            Risultato.Text = operazione;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            operazione += button11.Text;
            Risultato.Text = operazione;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            operazione += button7.Text;
            Risultato.Text = operazione;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            operazione += button8.Text;
            Risultato.Text = operazione;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            operazione += button9.Text;
            Risultato.Text = operazione;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            operazione += button6.Text;
            Risultato.Text = operazione;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            operazione += button5.Text;
            Risultato.Text = operazione;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            operazione += button4.Text;
            Risultato.Text = operazione;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            operazione += button3.Text;
            Risultato.Text = operazione;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            operazione += button2.Text;
            Risultato.Text = operazione;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            operazione += button1.Text;
            Risultato.Text = operazione;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}