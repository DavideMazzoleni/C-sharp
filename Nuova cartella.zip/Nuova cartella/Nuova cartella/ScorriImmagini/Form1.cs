using System.Windows.Forms;
using static System.Windows.Forms.DataFormats;

namespace ScorriImmagini
{
    public partial class Base : Form
    {
        private int i = 0, j = 0, k = 0, dimnsion;
        private string[] file = new string[0];
        private String line;
        private StreamReader sr = new StreamReader("../../../../Descrizioni.txt");
        private List <string> lines = new List<string>();

        public Base()
        {
            InitializeComponent();
        }

        private void START_Click(object sender, EventArgs e)
        {

            string sup = controlloVelocita.Text;
            int time = Convert.ToInt32(sup);
            //label1.Text = time.ToString();
            timer.Interval = 1000 * time;
            if (!file[k].Equals(""))
            {
                timer.Enabled = true;
                Files.Visible = false;
                controlloVelocita.Visible = false;
                button3.Visible = false;
            }
            else
            {
                MessageBox.Show("Selezionare una cartella");
                //MessageBox.Show(file[k]);
            }
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            string formato = file[i].Substring((file[i].Length - 3), 3);

            if (formato == "png" || formato == "jpg" || formato == "gif")
            {
                pictureBox1.ImageLocation = file[i];
                base.Text = file[i];
                Descrizione.Text = lines[j];
                j++;
            }

            if (i < dimnsion - 1)
                i++;
            else
            {
                j = 0;
                i = 0;
                string formato2;
                //MessageBox.Show(i.ToString());
                do
                {
                    formato2 = file[i].Substring((file[i].Length - 3), 3);
                    i++;
                } while (formato2 != "png" && formato2 != "jpg" && formato2 != "gif");
                i--;

            }
            //label1.Text = formato;
        }

        private void STOP_Click(object sender, EventArgs e)
        {
            timer.Enabled = false;
            button3.Visible = true;
        }

        private void OPEN_Click(object sender, EventArgs e)
        {
            folderBrowserDialog.ShowDialog();
            file = Directory.GetFiles(folderBrowserDialog.SelectedPath);
            dimnsion = file.Length;
            string formato;
            //MessageBox.Show(i.ToString());
            do
            {
                formato = file[i].Substring((file[i].Length - 3), 3);
                pictureBox1.ImageLocation = file[i];
                i++;
                k++;
            } while (formato != "png" && formato != "jpg" && formato != "gif");
 
            //MessageBox.Show(k.ToString());

            line = sr.ReadLine();
            lines.Add(line);
            //Continue to read until you reach end of file
            while (line != null)
            {
                line = sr.ReadLine();
                lines.Add(line);
            }
            //close the file
            sr.Close();
            Descrizione.Visible = true;
            Descrizione.Text = lines[0];
        }

        private void EXIT_Click(object sender, EventArgs e)
        {
            timer.Enabled = false;
            Files.Visible = true;
            controlloVelocita.Visible = true;
            pictureBox1.ImageLocation = file[k-1];
            Descrizione.Text = lines[0];
        }
    }
}