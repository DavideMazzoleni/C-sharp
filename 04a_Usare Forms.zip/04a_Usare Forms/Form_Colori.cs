﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace due_forms
{
    public partial class Form_Colori : Form
    {
        public Form_Colori()
        {
            InitializeComponent();
        }
    }
}
