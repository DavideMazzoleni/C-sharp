﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace slideshow
{
    
    public partial class Form1 : Form
    {
        private bool isSlideshowPlaying = false;
        private int currentImageIndex = 0;
        private string[] imageFiles;

        public Form1()
        {
            InitializeComponent();
        }

        private void FileExplorerButton_Click(object sender, EventArgs e)
        {
            if (browserCartella.ShowDialog() == DialogResult.OK)
            {
                imageFiles = Directory.GetFiles(browserCartella.SelectedPath, "*.*", SearchOption.TopDirectoryOnly)
                    .Where(file => file.ToLower().EndsWith(".png") || file.ToLower().EndsWith(".jpg") 
                    || file.ToLower().EndsWith(".bmp") || file.ToLower().EndsWith(".gif"))
                    .ToArray();

                if (imageFiles.Length > 0)
                {
                    if (contenitoreImmagini.Image != null)
                        contenitoreImmagini.Image.Dispose();
                    contenitoreImmagini.Image = Image.FromFile(imageFiles[0]);
                    currentImageIndex = 0;
                    MostraControlli();
                    Text = "Slideshow Player - Percorso cartella: [" + browserCartella.SelectedPath + "]";
                }
                else
                {
                    MessageBox.Show("Non sono state trovate immagini nella cartella");
                }
            }
        }

        private void MostraControlli()
        {
            playPauseButton.Visible = true;
            intervalTrackbar.Visible = true;
            labelTrackbar.Visible = true;
        }

        private void PlayPauseButton_Click(object sender, EventArgs e)
        {
            playPauseButton.Image.Dispose();

            if (isSlideshowPlaying)
            {
                playPauseButton.Image = Image.FromFile("../../resources/avvia.png");
                slideshowTimer.Stop();
            }
            else
            {
                playPauseButton.Image = Image.FromFile("../../resources/pausa.png");
                stopButton.Visible = true;
                intervalTrackbar.Enabled = false;
                slideshowTimer.Interval = intervalTrackbar.Value * 1000;
                slideshowTimer.Start();
            }

            isSlideshowPlaying = !isSlideshowPlaying;
        }

        private void StopButton_Click(object sender, EventArgs e)
        {
            playPauseButton.Image.Dispose();
            playPauseButton.Image = Image.FromFile("../../resources/avvia.png");
            stopButton.Visible = false;
            intervalTrackbar.Enabled = true;
            isSlideshowPlaying = false;
            slideshowTimer.Stop();

            contenitoreImmagini.Image.Dispose();
            contenitoreImmagini.Image = Image.FromFile(imageFiles[0]);
            currentImageIndex = 0;
        }

        private void intervalTrackbar_ValueChanged(object sender, EventArgs e)
        {
            labelTrackbar.Text = "Intervallo di scorrimento: " + intervalTrackbar.Value.ToString() + " second" +
                                 (intervalTrackbar.Value == 1 ? "o" : "i"); 
        }

        private void UpdateImage(object sender, EventArgs e)
        {
            currentImageIndex++;
            if (currentImageIndex >= imageFiles.Length)
                currentImageIndex = 0;
            contenitoreImmagini.Image.Dispose();
            contenitoreImmagini.Image = Image.FromFile(imageFiles[currentImageIndex]);
        }

        private void browserCartella_HelpRequest(object sender, EventArgs e)
        {

        }
    }
}
